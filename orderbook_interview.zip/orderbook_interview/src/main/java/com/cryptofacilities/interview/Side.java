package com.cryptofacilities.interview;

/**
 * Created by CF-8 on 6/27/2017.
 */
public enum Side {
    buy, sell;
}
